@author William Wallace
@date 22/05/2020


EXPLANATION
Etude 3 - Arithmetic forms equations to reach a specified target number using multiplication or addition, 
when given operands and a mode from stdin, if it is possible. 
The two modes are denoted with characters: "N" for operations to be performed in their normal sequence, 
and "L" for operations to be applied form left to right.

HOW TO RUN
To run Etude 3, open VSCode or a similar code editor and run by typing "javac ArithmeticFinal.java" without quotation marks
while in the directory containing ArithmeticFinal.
To get the answer, the first line of input must contain the operands separated by spaces. The second line must contain 
the mode and the target number separated by a space. 
If no answer is possible for the input, the terminal will print the mode, target number, and "impossible" - all separated by spaces. 

For parsing a txt file with multiple tests, again ensure there is one test case per two lines.
In a code editor, type "cat <text-filename-here> | java ArithmeticFinal" without quotation marks, and replacing the file in the pointy brackets. 

For more information, refer to the PDF outlining "Etude 3 - Arithmetic" in the current folder. 

TEST CASES:

Input:
1 2 3
7 N
1 2 3
9 L
1 2 3
100 N
24
24 N
98
98 L
1312073 -280 0
0 N
10807 -31027 0
0 L
1 2 3 4 5 
120 N
1 2 3 4 5
120 L 
1 2 3 4 5
114 L
1 2 3 4 5 1 
120 N
1 2 3 4 5 1
120 L
9 9 9 9 9 934 
23443421 N

Output:
N 7 1 + 2 * 3 
L 9 1 + 2 * 3 
N 100 impossible
N 24
L 98
N 0 1312073 * -280 * 0 
L 0 10807 + -31027 * 0
N 120 1 * 2 * 3 * 4 * 5
L 120 1 + 2 + 3 * 4 * 5
L 114 impossible
N 120 1 * 2 * 3 * 4 * 5 * 1
L 120 1 + 2 + 3 * 4 * 5 * 1
N 23443421 impossible